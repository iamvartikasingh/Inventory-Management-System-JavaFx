# Java-Based-Inventory-Management-System

Installation guide_____

1. Create the database (stockDB) in the Lib folder
2. All the required dependencies are obtained from the Maven repository. No need to add JAR files, but load the project for the first time with an internet connection.
3. Run the code.


GUI

![Screenshot 2023-11-15 001514](https://github.com/Randil-Hasanga/Stock-Portfolio-Management-System/assets/126873904/9d2f6325-70de-442d-a9b3-260c50b1ffee)

![Screenshot 2023-11-15 001607](https://github.com/Randil-Hasanga/Stock-Portfolio-Management-System/assets/126873904/dc411d36-f474-471b-950e-996b9d420106)

![Screenshot 2023-11-15 001714](https://github.com/Randil-Hasanga/Stock-Portfolio-Management-System/assets/126873904/2401675a-906a-498b-9232-be6fb7932797)
