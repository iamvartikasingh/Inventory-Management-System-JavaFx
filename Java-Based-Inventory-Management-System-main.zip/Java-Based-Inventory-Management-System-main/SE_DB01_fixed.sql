USE stockDB;
SELECT * FROM stockDB.user;
